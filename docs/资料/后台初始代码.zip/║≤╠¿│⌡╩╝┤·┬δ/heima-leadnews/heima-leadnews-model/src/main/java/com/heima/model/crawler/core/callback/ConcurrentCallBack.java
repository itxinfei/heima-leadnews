package com.heima.model.crawler.core.callback;

public interface ConcurrentCallBack {

    public boolean filter();
}
