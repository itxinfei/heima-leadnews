package com.heima.model.user.pojos;

import lombok.Data;

@Data
public class ApUserDynamicList {
    private Integer id;
    private Integer userId;
    private Integer dynamicId;

}