package com.heima.model.article.pojos;

import lombok.Data;

@Data
public class ApEquipmentCode {
    private Integer id;
    private Integer equipmentId;
    private String code;

}