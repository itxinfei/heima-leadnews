package com.heima.model.article.pojos;

import lombok.Data;

@Data
public class ApArticleSDto {
    private Long authorId;
    private Long count;
}
