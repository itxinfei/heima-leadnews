export default {
    tabTitles: [
        {
            title: '主页',
            icon:'\uf015'
        },
        {
            title: '问题',
            icon:'\uf128'
        },
        {
            title: '视频',
            badge: 5,
            icon:'\uf03d'
        },
        {
            title: '我的',
            dot: true,
            icon:'\uf007'
        }
    ]
}
