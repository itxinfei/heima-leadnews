const lang = {
    load_new_text:'正在与火星通信......',
    load_more_text:'正在加载更多......'
}
export default lang
