import zh from "./zh"

const lang = zh

export default lang
