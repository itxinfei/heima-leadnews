package com.heima.model.crawler.core.callback;

/**
 * 数据校验接口
 */
public interface DataValidateCallBack {

    public boolean validate(String content);
}
