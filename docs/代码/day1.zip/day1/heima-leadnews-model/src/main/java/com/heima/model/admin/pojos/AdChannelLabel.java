package com.heima.model.admin.pojos;

import lombok.Data;

@Data
public class AdChannelLabel {
    private Integer id;
    private Integer channelId;
    private Integer labelId;
    private Integer ord;
}