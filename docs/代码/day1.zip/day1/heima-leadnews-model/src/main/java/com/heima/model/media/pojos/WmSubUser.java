package com.heima.model.media.pojos;

import lombok.Data;

@Data
public class WmSubUser {
    private Integer id;
    private Integer parentId;
    private Integer childrenId;

}