package com.heima.common.article.constans;

public class ArticleConstans {

    public static final Short LOADTYPE_LOAD_MORE = 1;
    public static final Short LOADTYPE_LOAD_NEW = 2;

    public static final String DEFAULT_TAG = "__all__";
}
